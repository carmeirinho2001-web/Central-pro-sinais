// Central Pro Sinais - Fase 1.2 (Layout + API opcional)
// Se a API estiver rodando (app.py), o painel puxa jogos reais.
// Se não estiver, usa dados de exemplo (seed).

const API_BASE = "";
 // mesmo host (Flask serve o web), então pode ficar vazio.

const state = {
  role: "guest", // guest | free | vip | admin
  leagues: [
    { code:"PL",  name:"Premier League" },
    { code:"PD",  name:"La Liga" },
    { code:"SA",  name:"Serie A" },
    { code:"BL1", name:"Bundesliga" },
    { code:"FL1", name:"Ligue 1" },
    { code:"BSA", name:"Brasileirão Série A" },
    { code:"CL",  name:"Champions League" },
    { code:"EL",  name:"Europa League" }
  ],
  games: [],
  signals: [],
  history: []
};

const $ = (q) => document.querySelector(q);
const $$ = (q) => Array.from(document.querySelectorAll(q));

function setRole(role){
  state.role = role;
  $("#rolePill").textContent = `Modo: ${role.toUpperCase()}`;
  $$(".admin-only").forEach(el => {
    el.style.display = (role === "admin") ? "" : "none";
  });

  const isVip = role === "vip" || role === "admin";
  $("#vipTag").textContent = isVip ? "Acesso liberado" : "Trancado";
  $("#vipSignals").classList.toggle("hidden", !isVip);
  $("#vipCard").querySelector(".lock").style.display = isVip ? "none" : "flex";
  renderAll();
}

function toBRTimeFromISO(iso){
  // iso em UTC -> mostra em pt-BR (o navegador converte para seu fuso)
  const d = new Date(iso);
  return d.toLocaleString("pt-BR", { day:"2-digit", month:"2-digit", hour:"2-digit", minute:"2-digit" });
}

function badge(status){
  if(status === "approved") return `<span class="tag ok">🟢 Aprovado</span>`;
  if(status === "rejected") return `<span class="tag bad">🔴 Reprovado</span>`;
  return `<span class="tag neutral">🟡 Pendente</span>`;
}

function marketLabel(m){
  if(m === "home") return "Vitória Mandante";
  if(m === "away") return "Vitória Visitante";
  if(m === "over25") return "Over 2.5";
  if(m === "btts") return "Ambas Marcam";
  return "—";
}

function seed(){
  const now = new Date();
  const sample = [
    { league:"Premier League", match:"Arsenal x Tottenham", minutes: 120 },
    { league:"La Liga", match:"Real Madrid x Sevilla", minutes: 240 },
    { league:"Serie A", match:"Inter x Roma", minutes: 360 },
    { league:"Bundesliga", match:"Bayern x Dortmund", minutes: 480 },
    { league:"Ligue 1", match:"PSG x Lyon", minutes: 600 },
    { league:"Brasileirão Série A", match:"Flamengo x Palmeiras", minutes: 720 },
    { league:"Champions League", match:"Man City x Barcelona", minutes: 840 },
    { league:"Europa League", match:"Liverpool x Milan", minutes: 960 },
  ];

  state.games = sample.map((g, i) => {
    const dt = new Date(now.getTime() + g.minutes * 60 * 1000);
    const confidence = Math.floor(62 + (i*3) % 25);
    const status = (i % 3 === 0) ? "approved" : (i % 3 === 1) ? "pending" : "rejected";
    const market = (i % 4 === 0) ? "over25" : (i % 4 === 1) ? "btts" : (i % 4 === 2) ? "home" : "away";
    return {
      id: `demo_${i+1}`,
      league: g.league,
      match: g.match,
      utcDate: dt.toISOString(),
      market,
      confidence,
      status,
      tier: (confidence >= 75) ? "vip" : "free"
    };
  });

  state.signals = state.games
    .filter(g => g.status === "approved")
    .map(g => ({
      id: `s_${g.id}`,
      ...g,
      reason: "Forma recente + média de gols + mando de campo (demonstração)."
    }));

  state.history = state.signals.map((s, idx) => ({
    ...s,
    result: (idx % 4 === 0) ? "❌" : "✅"
  }));
}

async function tryLoadFromAPI(){
  try{
    const res = await fetch(`${API_BASE}/api/games?hours=24`, { cache: "no-store" });
    if(!res.ok) throw new Error("api not ok");
    const data = await res.json();

    if(!data || !Array.isArray(data.games)) throw new Error("invalid payload");

    state.games = data.games.map((g, i) => ({
      id: g.id || `g_${i}`,
      league: g.league,
      match: g.match,
      utcDate: g.utcDate,
      market: g.market || "over25",
      confidence: g.confidence ?? 70,
      status: g.status || "pending",
      tier: g.tier || ((g.confidence ?? 70) >= 80 ? "vip" : "free"),
      reason: g.reason || "Análise automática (placeholder)."
    }));

    state.games = state.games.filter(g => {
      const t = new Date(g.utcDate).getTime();
      const now = Date.now();
      // mantém apenas jogos futuros (com 2min de tolerância)
      return t >= (now - 2*60*1000);
    });

    state.signals = []; // na fase seguinte, virão da API
    state.history = [];
    return true;
  }catch(e){
    return false;
  }
}

function renderFilters(){
  const leagueSel = $("#filterLeague");
  leagueSel.innerHTML = `<option value="all">Todas as ligas</option>` +
    state.leagues.map(l => `<option value="${l.name}">${l.name}</option>`).join("");

  const contentPick = $("#contentPick");
  contentPick.innerHTML = state.signals.map(s => `<option value="${s.id}">${s.league} • ${s.match}</option>`).join("");
}

function renderKPIs(){
  const approvedToday = state.games.filter(g => g.status === "approved").length;
  $("#kpiToday").textContent = approvedToday;
  $("#kpi24h").textContent = state.games.length;
  $("#kpiHit").textContent = state.history.length ? "—" : "72%";

  $("#hist7").textContent = state.history.length ? "—" : "71%";
  $("#hist30").textContent = state.history.length ? "—" : "68%";
  $("#histTotal").textContent = state.history.length;
}

function renderGamesTable(){
  const league = $("#filterLeague").value;
  const status = $("#filterStatus").value;

  let rows = state.games.slice();
  if(league !== "all") rows = rows.filter(g => g.league === league);
  if(status !== "all") rows = rows.filter(g => g.status === status);

  $("#gamesTable").innerHTML = rows.map(g => `
    <div class="row">
      <div class="muted small">${toBRTimeFromISO(g.utcDate)}</div>
      <div>
        <div style="font-weight:900">${g.match}</div>
        <div class="muted small">${g.league} • Mercado: ${marketLabel(g.market)} • Conf.: ${g.confidence}%</div>
      </div>
      <div>${badge(g.status)}</div>
      <div class="muted small">${g.tier.toUpperCase()}</div>
    </div>
  `).join("") || `<div class="muted small">Nenhum jogo com esses filtros.</div>`;
}

function renderSignals(){
  const free = state.signals.filter(s => s.tier === "free");
  const vip = state.signals.filter(s => s.tier === "vip");

  $("#freeSignals").innerHTML = free.map(s => `
    <div class="gamecard">
      <div class="gc-top">
        <div>
          <div class="gc-match">${s.match}</div>
          <div class="gc-meta muted small">
            <span>${s.league}</span> •
            <span>${toBRTimeFromISO(s.utcDate)}</span> •
            <span>${marketLabel(s.market)}</span>
          </div>
        </div>
        <span class="tag ok">${s.confidence}%</span>
      </div>
      <div class="muted small">${s.reason}</div>
    </div>
  `).join("") || `<div class="muted small">Sem sinais free no momento.</div>`;

  $("#vipSignals").innerHTML = vip.map(s => `
    <div class="gamecard">
      <div class="gc-top">
        <div>
          <div class="gc-match">${s.match}</div>
          <div class="gc-meta muted small">
            <span>${s.league}</span> •
            <span>${toBRTimeFromISO(s.utcDate)}</span> •
            <span>${marketLabel(s.market)}</span>
          </div>
        </div>
        <span class="tag ok">${s.confidence}%</span>
      </div>
      <div class="muted small">${s.reason}</div>
    </div>
  `).join("") || `<div class="muted small">Sem sinais VIP no momento.</div>`;
}

function renderAdminQueue(){
  const pending = state.games.filter(g => g.status === "pending");
  $("#adminQueue").innerHTML = pending.map(g => `
    <div class="gamecard" data-id="${g.id}">
      <div class="gc-top">
        <div>
          <div class="gc-match">${g.match}</div>
          <div class="gc-meta muted small">
            <span>${g.league}</span> •
            <span>${toBRTimeFromISO(g.utcDate)}</span> •
            <span>Conf.: ${g.confidence}%</span>
          </div>
        </div>
        <span class="tag neutral">Pendente</span>
      </div>

      <div class="gc-actions">
        <select class="select" data-field="market">
          <option value="home">Vitória Mandante</option>
          <option value="away">Vitória Visitante</option>
          <option value="over25" selected>Over 2.5</option>
          <option value="btts">Ambas Marcam</option>
        </select>

        <button class="btn free" data-action="tier" data-tier="free">Liberar Free</button>
        <button class="btn vip" data-action="tier" data-tier="vip">Liberar VIP</button>

        <button class="btn approve" data-action="approve">Aprovar</button>
        <button class="btn reject" data-action="reject">Reprovar</button>
      </div>
    </div>
  `).join("") || `<div class="muted small">Sem jogos pendentes 👍</div>`;

  $$("#adminQueue .gamecard").forEach(card => {
    const id = card.dataset.id;

    card.querySelector('[data-field="market"]').addEventListener("change", (e) => {
      const g = state.games.find(x => x.id === id);
      g.market = e.target.value;
    });

    card.querySelectorAll("[data-action]").forEach(btn => {
      btn.addEventListener("click", () => {
        const g = state.games.find(x => x.id === id);

        if(btn.dataset.action === "tier"){
          g.tier = btn.dataset.tier;
          return renderAll();
        }

        if(btn.dataset.action === "approve"){
          g.status = "approved";
          state.signals.push({
            id: `s_${g.id}`,
            ...g,
            reason: "Aprovado pelo Admin. (Na próxima fase: motivo automático do modelo.)"
          });
        }

        if(btn.dataset.action === "reject"){
          g.status = "rejected";
        }

        renderAll();
      });
    });
  });
}

function renderHistory(){
  $("#historyList").innerHTML = state.history.map(h => `
    <div class="row">
      <div class="muted small">${toBRTimeFromISO(h.utcDate)}</div>
      <div>
        <div style="font-weight:900">${h.match}</div>
        <div class="muted small">${h.league} • ${marketLabel(h.market)} • Conf.: ${h.confidence}%</div>
      </div>
      <div>${h.result === "✅" ? `<span class="tag ok">✅ Bateu</span>` : `<span class="tag bad">❌ Não bateu</span>`}</div>
      <div class="muted small">${h.tier.toUpperCase()}</div>
    </div>
  `).join("") || `<div class="muted small">Sem histórico ainda.</div>`;
}

function renderContentPreview(){
  const pickId = $("#contentPick").value;
  const s = state.signals.find(x => x.id === pickId);
  if(!s) return;

  $("#pcLeague").textContent = s.league;
  $("#pcTime").textContent = toBRTimeFromISO(s.utcDate);
  $("#pcMatch").textContent = s.match;
  $("#pcSignal").textContent = `Sinal: ${marketLabel(s.market)}`;
  $("#pcPct").textContent = `${s.confidence}%`;
  $("#pcBar").style.width = `${s.confidence}%`;
}

function renderAll(){
  renderFilters();
  renderKPIs();
  renderGamesTable();
  renderSignals();
  renderAdminQueue();
  renderHistory();
  renderContentPreview();
}

function showView(name){
  $$(".view").forEach(v => v.classList.add("hidden"));
  $(`#view-${name}`).classList.remove("hidden");
  $$(".nav-item").forEach(b => b.classList.toggle("active", b.dataset.view === name));
}
$$(".nav-item").forEach(btn => btn.addEventListener("click", () => showView(btn.dataset.view)));

function openModal(){
  $("#loginModal").classList.remove("hidden");
  $("#loginModal").setAttribute("aria-hidden","false");
}
function closeModal(){
  $("#loginModal").classList.add("hidden");
  $("#loginModal").setAttribute("aria-hidden","true");
}
$("#btnOpenLogin").addEventListener("click", openModal);
$("#btnCloseLogin").addEventListener("click", closeModal);
$("#modalBackdrop").addEventListener("click", closeModal);

$$('#loginModal [data-role]').forEach(b => {
  b.addEventListener("click", () => {
    setRole(b.dataset.role);
    closeModal();
  });
});

$("#btnGoAdmin").addEventListener("click", () => showView("admin"));
$("#btnRefresh").addEventListener("click", async () => {
  const ok = await tryLoadFromAPI();
  if(!ok){
    seed();
    showApiError();
  }
  renderAll();
});

$("#filterLeague").addEventListener("change", renderGamesTable);
$("#filterStatus").addEventListener("change", renderGamesTable);

$("#btnUpgrade").addEventListener("click", () => { setRole("vip"); showView("signals"); });

$("#btnPublish").addEventListener("click", () => {
  alert("Publicação simulada ✅ (na próxima fase: salva no banco e libera no painel do usuário)");
});

$("#btnBulkApprove").addEventListener("click", () => {
  const pending = state.games.filter(g => g.status === "pending").sort((a,b)=>b.confidence-a.confidence).slice(0,3);
  pending.forEach(g => {
    g.status = "approved";
    state.signals.push({ id: `s_${g.id}`, ...g, reason: "Aprovado em lote." });
  });
  renderAll();
});

$("#contentPick").addEventListener("change", renderContentPreview);
$("#btnGenCard").addEventListener("click", () => { renderContentPreview(); $("#copyBox").value = "Card gerado na prévia ✅\n(Dica: tire um print e poste nos Stories/Reels)"; });

$("#btnGenCopy").addEventListener("click", () => {
  const s = state.signals.find(x => x.id === $("#contentPick").value);
  if(!s) return;
  $("#copyBox").value =
`⚽ ${s.match}
🏆 ${s.league}
⏰ ${toBRTimeFromISO(s.utcDate)}
✅ Sinal: ${marketLabel(s.market)}
📊 Confiança: ${s.confidence}%

🧠 Motivo: análise de desempenho + tendência de gols + mando de campo.
⚠️ Jogue com responsabilidade.

🔗 Quer o painel completo (VIP)? Chama no direct / Link na bio.`;
});

$("#btnGenScript").addEventListener("click", () => {
  const s = state.signals.find(x => x.id === $("#contentPick").value);
  if(!s) return;
  $("#copyBox").value =
`🎬 Roteiro (10–12s)
1) “Jogo analisado agora: ${s.match}.”
2) “Sinal: ${marketLabel(s.market)} com ${s.confidence}% de confiança.”
3) “Eu só posto quando passa no filtro.”
4) “Quer os sinais VIP? Link na bio / chama no direct.”`;
});

$("#btnCopy").addEventListener("click", async () => {
  try{ await navigator.clipboard.writeText($("#copyBox").value || ""); alert("Copiado ✅"); }
  catch(e){ alert("Não consegui copiar automaticamente. Selecione e copie manualmente."); }
});


function showApiError(){
  let el = document.getElementById("apiErrorBanner");
  if(!el){
    el = document.createElement("div");
    el.id = "apiErrorBanner";
    el.style.position = "fixed";
    el.style.left = "16px";
    el.style.right = "16px";
    el.style.bottom = "16px";
    el.style.zIndex = "9999";
    el.style.padding = "12px 14px";
    el.style.borderRadius = "16px";
    el.style.border = "1px solid rgba(239,68,68,.55)";
    el.style.background = "rgba(239,68,68,.12)";
    el.style.backdropFilter = "blur(8px)";
    el.innerHTML = `
      <div style="font-weight:900; margin-bottom:6px;">⚠️ API não está rodando</div>
      <div style="font-size:12px; color:#eaf0ff; opacity:.9; margin-bottom:10px;">
        Para usar jogos reais, inicie pelo arquivo <b>ABRIR_APP.bat</b> (na pasta principal) e mantenha a janela preta aberta.
      </div>
      <button id="btnRetryApi" class="btn primary">Tentar novamente</button>
    `;
    document.body.appendChild(el);
    document.getElementById("btnRetryApi").onclick = async () => {
      const ok = await boot();
      if(ok) el.remove();
    };
  }
}

async function boot(){
  const ok = await tryLoadFromAPI();
  if(!ok){
    showApiError();
    // limpa listas
    state.games = [];
    state.signals = [];
    state.history = [];
    renderAll();
    return false;
  }
  renderAll();
  return true;
}

// INIT
(async () => {
  setRole("guest");
  showView("dashboard");
  await boot();
})();
