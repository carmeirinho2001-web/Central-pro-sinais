# Central Pro Sinais (Web + API Local)

## 1) Abrir só o layout (sem API)
Abra: web/index.html

## 2) Abrir com jogos reais (API)
### Passo A: pegar o token (gratuito)
1. Crie uma conta no football-data.org e pegue seu token (X-Auth-Token).
2. Abra o arquivo config.json e cole no campo FOOTBALL_DATA_TOKEN.

### Passo B: iniciar API
1. Entre na pasta api/
2. Dê 2 cliques em run_api.bat
3. Abra no navegador: http://127.0.0.1:5000

Se a API estiver rodando, o painel puxa jogos reais das 8 ligas nas próximas 24h.


v4: Filtro anti-jogos passados + não mostra jogos que começam em menos de 30min (ajustável por /api/games?min=30). Aprovação automática simples baseada em confiança.


=== USO SUPER FÁCIL (sem mexer em nada) ===
1) Clique em ABRIR_APP.bat (na pasta principal)
2) Use o painel em http://127.0.0.1:5000
3) Para fechar: na janela preta da API aperte Ctrl+C

=== MONETIZAÇÃO (IG/TikTok) ===
FREE: poste 1-3 sinais por dia e convide pro VIP.
VIP: poste prints do painel + "Acesso VIP".
CTA (8-10s): "Quer os sinais VIP antes de todo mundo? Link na bio ou chama no direct."
