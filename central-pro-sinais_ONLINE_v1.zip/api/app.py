"""
Central Pro Sinais - API local (Flask)
- Serve o painel web (pasta /web)
- Endpoint /api/games retorna jogos das próximas horas (por padrão 24h)
Fonte dos jogos: football-data.org (v4)
"""

from __future__ import annotations

import json
import os
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import requests
from flask import Flask, jsonify, request, send_from_directory

BASE_DIR = Path(__file__).resolve().parent.parent
WEB_DIR = BASE_DIR / "web"
CONFIG_PATH = BASE_DIR / "config.json"

FOOTBALL_DATA_BASE = "https://api.football-data.org/v4"

# 8 ligas escolhidas (códigos do football-data.org)
COMPETITIONS = {
    "PL": "Premier League",
    "PD": "La Liga",
    "SA": "Serie A",
    "BL1": "Bundesliga",
    "FL1": "Ligue 1",
    "BSA": "Brasileirão Série A",
    "CL": "Champions League",
    "EL": "Europa League",
}

@dataclass
class Game:
    id: str
    league: str
    match: str
    utcDate: str
    confidence: int

def load_token() -> Optional[str]:
    # 1) variável de ambiente
    tok = os.getenv("FOOTBALL_DATA_TOKEN")
    if tok and tok.strip():
        return tok.strip()

    # 2) config.json
    if CONFIG_PATH.exists():
        try:
            cfg = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
            tok2 = (cfg.get("FOOTBALL_DATA_TOKEN") or "").strip()
            return tok2 or None
        except Exception:
            return None
    return None

def utc_now() -> datetime:
    return datetime.now(timezone.utc)

def date_range_for_hours(hours: int) -> Tuple[str, str]:
    # football-data usa filtros por data (YYYY-MM-DD). Vamos cobrir a janela no UTC.
    start = utc_now()
    end = start + timedelta(hours=hours)
    return start.date().isoformat(), end.date().isoformat()

def fetch_matches(date_from: str, date_to: str, token: str) -> List[dict]:
    # Pega TODOS os jogos nesse intervalo, depois filtramos pelas competições desejadas.
    # Docs: /v4/matches?dateFrom=YYYY-MM-DD&dateTo=YYYY-MM-DD com header X-Auth-Token
    url = f"{FOOTBALL_DATA_BASE}/matches"
    headers = {"X-Auth-Token": token}
    params = {"dateFrom": date_from, "dateTo": date_to}
    r = requests.get(url, headers=headers, params=params, timeout=20)
    r.raise_for_status()
    data = r.json()
    return data.get("matches", [])

def within_next_hours(utc_iso: str, hours: int) -> bool:
    try:
        d = datetime.fromisoformat(utc_iso.replace("Z", "+00:00"))
    except Exception:
        return False
    start = utc_now()
    end = start + timedelta(hours=hours)
    return start <= d <= end

def compute_market(conf: int) -> str:
    # regra simples: conf maior -> mercado mais agressivo
    if conf >= 82:
        return "over25"
    if conf >= 76:
        return "btts"
    if conf >= 70:
        return "home"
    return "away"

def compute_reason(conf: int) -> str:
    # texto padrão para o painel
    if conf >= 82:
        return "Alta tendência de gols (linha Over 2.5)."
    if conf >= 76:
        return "Boa chance de gols para ambos (BTTS)."
    if conf >= 70:
        return "Leve vantagem do mandante (mando + estabilidade)."
    return "Jogo equilibrado; valor pode estar no visitante."

def compute_confidence(match: dict) -> int:
    # Nesta fase: uma “confiança” simples baseada em status/etapa do jogo (placeholder)
    # Depois entra o motor real.
    status = (match.get("status") or "").upper()
    if status == "TIMED":
        return 72
    if status == "SCHEDULED":
        return 70
    return 68

app = Flask(__name__)

@app.get("/")
def home():
    return send_from_directory(WEB_DIR, "index.html")

@app.get("/assets/<path:filename>")
def assets(filename: str):
    return send_from_directory(WEB_DIR / "assets", filename)

@app.get("/api/status")
def api_status():
    token = load_token()
    return jsonify({
        "ok": True,
        "has_token": bool(token),
        "source": "football-data.org",
        "competitions": COMPETITIONS,
    })

@app.get("/api/games")
def api_games():
    hours = int(request.args.get("hours", "24"))
    grace_minutes = int(request.args.get("grace", "2"))
    min_start_minutes = int(request.args.get("min", "30"))
    hours = max(1, min(hours, 48))  # limita 1..48 para segurança
    grace_minutes = max(0, min(grace_minutes, 60))
    min_start_minutes = max(0, min(min_start_minutes, 360))

    token = load_token()
    if not token:
        return jsonify({
            "ok": False,
            "error": "TOKEN_NOT_FOUND",
            "message": "Coloque seu token do football-data.org em config.json (FOOTBALL_DATA_TOKEN) ou na variável de ambiente FOOTBALL_DATA_TOKEN."
        }), 400

    date_from, date_to = date_range_for_hours(hours)

    try:
        matches = fetch_matches(date_from, date_to, token)
    except requests.HTTPError as e:
        return jsonify({"ok": False, "error": "UPSTREAM_HTTP_ERROR", "message": str(e)}), 502
    except Exception as e:
        return jsonify({"ok": False, "error": "UPSTREAM_ERROR", "message": str(e)}), 502

    games: List[Game] = []

    for m in matches:
        comp = (m.get("competition") or {})
        code = (comp.get("code") or "").strip()
        if code not in COMPETITIONS:
            continue

        utc_date = (m.get("utcDate") or "").strip()
        status = (m.get('status') or '').upper()
        if status not in {'SCHEDULED','TIMED'}:
            continue

        if not utc_date or not within_next_hours(utc_date, hours, grace_minutes=grace_minutes):
            continue

        # não mostrar jogo muito em cima da hora (ex.: menos de 30min)
        try:
            d = datetime.fromisoformat(utc_date.replace('Z', '+00:00'))
        except Exception:
            continue
        start_limit = utc_now() + timedelta(minutes=min_start_minutes)
        if d < start_limit:
            continue
            continue

        home = ((m.get("homeTeam") or {}).get("name") or "").strip()
        away = ((m.get("awayTeam") or {}).get("name") or "").strip()
        if not home or not away:
            continue

        conf = compute_confidence(m)
        market = compute_market(conf)
        status_out = "approved" if conf >= 75 else "pending"
        tier = "vip" if conf >= 80 else "free"
        games.append(Game(
            id=str(m.get("id") or ""),
            league=COMPETITIONS[code],
            match=f"{home} x {away}",
            utcDate=utc_date,
            confidence=conf,
            status=status_out,
            tier=tier,
            market=market,
            reason=compute_reason(conf),
        ))

    games.sort(key=lambda g: g.utcDate)

    return jsonify({
        "ok": True,
        "hours": hours,
        "grace": grace_minutes,
        "min_start_minutes": min_start_minutes,
        "dateFrom": date_from,
        "dateTo": date_to,
        "games": [g.__dict__ for g in games],
    })

if __name__ == "__main__":
    # Servidor local
    app.run(host="127.0.0.1", port=5000, debug=False)
